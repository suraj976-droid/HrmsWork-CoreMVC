﻿using CodeFirstApproach.Data;
using CodeFirstApproach.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CodeFirstApproach.Controllers
{
    public class LeaveCalController : Controller

    {
        private readonly ApplicationDbContext _context;

        public LeaveCalController(ApplicationDbContext context)
        {
            _context = context;
        }

        // Action to display the calendar view
       // Action to display the calendar view 
        public IActionResult Calendars()
        {
            var userId = HttpContext.Session.GetInt32("userId");
            if (userId == null)
            {
                return RedirectToAction("SignIn", "Auth");
            }

            // Fetch leave types and leaves taken by the user
            var leaveTypes = _context.LeaveTypes.ToList();
            var userLeaves = _context.leaves
                .Include(l => l.LeaveType) // Include LeaveType for navigation
                .Where(l => l.UserID == userId)
                .ToList();

            // Calculate remaining leave for each leave type
            var remainingLeaves = new List<RemainingLeaveViewModel>();

            foreach (var leaveType in leaveTypes)
            {
                var usedDays = userLeaves
                    .Where(l => l.LeaveTypeID == leaveType.LeaveTypeID && l.Status == "Approved")
                    .Sum(l => (l.ToDate - l.FromDate).Days + 1); // Include both start and end dates

                remainingLeaves.Add(new RemainingLeaveViewModel
                {
                    LeaveTypeName = leaveType.LeaveTypeName,
                    MaxDays = leaveType.MaxDays,
                    UsedDays = usedDays,
                    ColorCode = GetColorCode(leaveType.LeaveTypeName) // Assign color code
                });
            }

            // Pass data to the view
            ViewBag.RemainingLeaves = remainingLeaves;
            return View();
        }

        // API endpoint to fetch leaves for FullCalendar
        public IActionResult GetLeaves()
        {
            var userId = HttpContext.Session.GetInt32("userId");
            if (userId == null)
            {
                return Json(new { });
            }

            // Fetch leaves taken by the user
            var leaves = _context.leaves
                .Include(l => l.LeaveType) // Include LeaveType for navigation
                .Where(l => l.UserID == userId)
                .Select(l => new
                {
                    id = l.LeaveID,
                    title = l.LeaveType.LeaveTypeName,
                    start = l.FromDate.ToString("yyyy-MM-dd"),
                    end = l.ToDate.AddDays(1).ToString("yyyy-MM-dd"), // Include end date
                    color = GetColorCode(l.LeaveType.LeaveTypeName), // Assign color based on leave type
                    status = l.Status
                })
                .ToList();

            return Json(leaves);
        }

        // Make this method static
        private static string GetColorCode(string leaveTypeName)
        {
            switch (leaveTypeName)
            {
                case "paid leave":
                    return "#FF5733"; // Orange
                case "sick leave":
                    return "#33FF57"; // Green
                case "maternity leave":
                    return "#3357FF"; // Blue
                default:
                    return "#CCCCCC"; // Gray
            }
        }
    }
}
