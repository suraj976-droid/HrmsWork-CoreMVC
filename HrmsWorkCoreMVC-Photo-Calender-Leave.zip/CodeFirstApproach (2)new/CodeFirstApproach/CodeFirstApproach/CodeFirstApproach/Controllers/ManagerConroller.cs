﻿using Microsoft.AspNetCore.Mvc;

using CodeFirstApproach.Data;
using Microsoft.AspNetCore.Mvc;
using CodeFirstApproach.Models;
using Microsoft.EntityFrameworkCore;

namespace CodeFirstApproach.Controllers
{
    public class ManagerController : Controller
    {
        private readonly ApplicationDbContext db;

        public ManagerController(ApplicationDbContext db)
        {
            this.db = db;
        }

        // Display all leave requests
        public IActionResult LeaveRequests()
        {
            var leaveRequests = db.leaves
                .Include(l => l.User)
                .Include(l => l.LeaveType)
                .ToList();

            return View(leaveRequests);
        }

        // Approve Leave Request
        public IActionResult ApproveLeave(int id)
        {
            var leave = db.leaves.Find(id);
            if (leave != null && leave.Status == "Pending")
            {
                leave.Status = "Approved";
                db.SaveChanges();
                TempData["success"] = "Leave Approved Successfully!";
            }
            else
            {
                TempData["error"] = "Invalid Leave Request!";
            }

            return RedirectToAction("LeaveRequests");
        }

        // Reject Leave Request
        public IActionResult RejectLeave(int id)
        {
            var leave = db.leaves.Find(id);
            if (leave != null && leave.Status == "Pending")
            {
                leave.Status = "Rejected";
                db.SaveChanges();
                TempData["error"] = "Leave Rejected!";
            }
            else
            {
                TempData["error"] = "Invalid Leave Request!";
            }

            return RedirectToAction("LeaveRequests");
        }

        // Rollback Leave Decision (Reset to Pending)
        public IActionResult RollbackLeave(int id)
        {
            var leave = db.leaves.Find(id);
            if (leave != null && (leave.Status == "Approved" || leave.Status == "Rejected"))
            {
                leave.Status = "Pending";
                db.SaveChanges();
                TempData["info"] = "Leave status rolled back to Pending!";
            }
            else
            {
                TempData["error"] = "Invalid Leave Request!";
            }

            return RedirectToAction("LeaveRequests");
        }
    }
}