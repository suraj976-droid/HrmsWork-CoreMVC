﻿using CodeFirstApproach.Data;
using CodeFirstApproach.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CodeFirstApproach.Controllers
{
    public class DesignationController : Controller
    {
        private readonly ApplicationDbContext db;

        public DesignationController(ApplicationDbContext db)
        {
            this.db = db;
        }

        // Index: Display all designations
        public IActionResult Index()
        {
            var data = db.AddDesignation.Include(d => d.Department).ToList(); // Include Department data
            return View(data);
        }

        // AddDesignation: Display the form to add a new designation
        public IActionResult AddDesignation()
        {
            ViewBag.Departments = db.AddDepartment.ToList(); // Populate dropdown for departments
            return View();
        }

        // AddDesignation: Handle form submission
        [HttpPost]
        public IActionResult AddDesignation(AddDesignation desig)
        {
           
                db.AddDesignation.Add(desig);
                db.SaveChanges();
                TempData["success"] = "Designation Added Successfully!!";
                return RedirectToAction("Index");
           
        }

        // DeleteDesignation: Delete a designation by ID
        public IActionResult DeleteDesignation(int id)
        {
            var data = db.AddDesignation.Find(id);
            if (data != null)
            {
                db.AddDesignation.Remove(data);
                db.SaveChanges();
                TempData["error"] = "Designation Deleted Successfully!!";
                return RedirectToAction("Index");
            }
            return NotFound();
        }

        // EditDesignation: Display the form to edit a designation
        public IActionResult EditDesignation(int id)
        {
            var data = db.AddDesignation.Find(id);
            if (data == null)
            {
                return NotFound();
            }
            ViewBag.Departments = db.AddDepartment.ToList(); // Populate dropdown for departments
            return View(data);
        }

        // EditDesignation: Handle form submission for editing
        [HttpPost]
        public IActionResult EditDesignation(AddDesignation desig)
        {
        
                db.AddDesignation.Update(desig);
                db.SaveChanges();
                TempData["upd"] = "Designation Updated Successfully!!";
                return RedirectToAction("Index");
         
            
            
        }
    }
}
