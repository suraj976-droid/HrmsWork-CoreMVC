﻿using CodeFirstApproach.Data;
using CodeFirstApproach.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CodeFirstApproach.Controllers
{
    public class RManagerController : Controller
    {
        private readonly ApplicationDbContext db;

        public RManagerController(ApplicationDbContext db)
        {
            this.db = db;
        }

        // Index: Display all reporting managers
        public IActionResult Index()
        {
            var data = db.RManager.ToList(); // Use RManager table
            return View(data);
        }

        // AddRManager: Display the form to add a new reporting manager
        public IActionResult AddRManager()
        {
            return View();
        }

        // AddRManager: Handle form submission
        [HttpPost]
        public IActionResult AddRManager(RManager rManager)
        {
            if (ModelState.IsValid)
            {
                db.RManager.Add(rManager); // Use RManager table
                db.SaveChanges();
                TempData["success"] = "Reporting Manager Added Successfully!!";
                return RedirectToAction("Index");
            }
            return View(rManager);
        }

        // DeleteRManager: Delete a reporting manager by ID
        public IActionResult DeleteRManager(int id)
        {
            var data = db.RManager.Find(id); // Use RManager table
            if (data != null)
            {
                db.RManager.Remove(data); // Use RManager table
                db.SaveChanges();
                TempData["error"] = "Reporting Manager Deleted Successfully!!";
                return RedirectToAction("Index");
            }
            return NotFound();
        }

        // EditRManager: Display the form to edit a reporting manager
        public IActionResult EditRManager(int id)
        {
            var data = db.RManager.Find(id); // Use RManager table
            if (data == null)
            {
                return NotFound();
            }
            return View(data);
        }

        // EditRManager: Handle form submission for editing
        [HttpPost]
        public IActionResult EditRManager(RManager rManager)
        {
            if (ModelState.IsValid)
            {
                db.RManager.Update(rManager); // Use RManager table
                db.SaveChanges();
                TempData["upd"] = "Reporting Manager Updated Successfully!!";
                return RedirectToAction("Index");
            }
            return View(rManager);
        }
    }
}
