﻿using CodeFirstApproach.Data;
using CodeFirstApproach.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CodeFirstApproach.Controllers
{
    public class EventTypeController : Controller
    {
        private readonly ApplicationDbContext db;

        public EventTypeController(ApplicationDbContext db)
        {
            this.db = db;
        }

        // GET: EventType
        public IActionResult Index()
        {
            return View(db.EventTypes.ToList());
        }

        // GET: EventType/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: EventType/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("EventTypeName,ColorCode,Status")] EventType eventType)
        {
            if (ModelState.IsValid)
            {
                db.Add(eventType);
                await db.SaveChangesAsync();
                TempData["success"] = "Event Type added successfully";
                return RedirectToAction(nameof(Index));
            }
            return View(eventType);
        }

        // GET: EventType/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var eventType = await db.EventTypes.FindAsync(id);
            if (eventType == null)
            {
                return NotFound();
            }
            return View(eventType);
        }

        // POST: EventType/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("EventTypeID,EventTypeName,ColorCode,Status")] EventType eventType)
        {
            if (id != eventType.EventTypeID)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    db.Update(eventType);
                    await db.SaveChangesAsync();
                    TempData["success"] = "Event Type updated successfully";
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!EventTypeExists(eventType.EventTypeID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(eventType);
        }

        // GET: EventType/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var eventType = await db.EventTypes
                .FirstOrDefaultAsync(m => m.EventTypeID == id);
            if (eventType == null)
            {
                return NotFound();
            }

            return View(eventType);
        }

        // POST: EventType/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var eventType = await db.EventTypes.FindAsync(id);
            db.EventTypes.Remove(eventType);
            await db.SaveChangesAsync();
            TempData["success"] = "Event Type deleted successfully";
            return RedirectToAction(nameof(Index));
        }

        private bool EventTypeExists(int id)
        {
            return db.EventTypes.Any(e => e.EventTypeID == id);
        }
    }
}
