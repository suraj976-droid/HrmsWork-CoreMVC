﻿using CodeFirstApproach.Data;
using CodeFirstApproach.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using System.Security.Claims;

namespace CodeFirstApproach.Controllers
{
    public class EmployeesController : Controller
    {
        private readonly ApplicationDbContext db;

        public EmployeesController(ApplicationDbContext db)
        {
            this.db = db;
        }

        public IActionResult ApplyLeave()
        {
            ViewBag.LeaveTypes = new SelectList(db.LeaveTypes.Where(l => l.Status == "Active").ToList(), "LeaveTypeID", "LeaveTypeName");
            return View();
        }

        [HttpPost]
        public IActionResult ApplyLeave(Leave leave)
        {
            if (ModelState.IsValid)
            {
                // Get logged-in UserID
                var userId = HttpContext.Session.GetInt32("userId");
                          
                leave.UserID = Convert.ToInt32(userId);  // Ensure it's an integer

                leave.Status = "Pending"; // Default status
                db.leaves.Add(leave);
                db.SaveChanges();

                TempData["success"] = "Leave Applied Successfully!";
                return RedirectToAction("EmployeeDashboard","Dashboard");
            }

            ViewBag.LeaveTypes = new SelectList(db.LeaveTypes.Where(l => l.Status == "Active").ToList(), "LeaveTypeID", "LeaveTypeName");
            return View(leave);
        }

        public IActionResult LeaveStatus()
        {
            
            int userId = Convert.ToInt32(HttpContext.Session.GetInt32("userId"));

            var leaves = this.db.leaves
                                 .Where(l => l.UserID == userId)
                                 .OrderByDescending(l => l.FromDate)
                                 .ToList();

            return View(leaves);
        }


    }
}