﻿using CodeFirstApproach.Models;
using Microsoft.EntityFrameworkCore;

namespace CodeFirstApproach.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        {
        }

        public DbSet<Emp> emps { get; set; }
        public DbSet<User> users { get; set; }
        public DbSet<EventType> EventTypes { get; set; }
        public DbSet<Event> Events { get; set; }
        public DbSet<AddDepartment> AddDepartment { get; set; }
        public DbSet<AddDesignation> AddDesignation { get; set; }
        public DbSet<Role> Role { get; set; }
        public DbSet<RManager> RManager { get; set; }
        public DbSet<AddEmployee> AddEmployee { get; set; }
        public DbSet<Leave> leaves { get; set; } // Property name is 'leaves'
        public DbSet<LeaveType> LeaveTypes { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Disable cascade delete for foreign keys
            modelBuilder.Entity<AddEmployee>()
                .HasOne(e => e.Role)
                .WithMany()
                .HasForeignKey(e => e.EmpRole)
                .OnDelete(DeleteBehavior.NoAction);

            modelBuilder.Entity<AddEmployee>()
                .HasOne(e => e.Department)
                .WithMany()
                .HasForeignKey(e => e.EmpDepartment)
                .OnDelete(DeleteBehavior.NoAction);

            modelBuilder.Entity<AddEmployee>()
                .HasOne(e => e.Designation)
                .WithMany()
                .HasForeignKey(e => e.EmpDesignation)
                .OnDelete(DeleteBehavior.NoAction);

            modelBuilder.Entity<AddEmployee>()
                .HasOne(e => e.ReportingManager)
                .WithMany()
                .HasForeignKey(e => e.EmpReportingManager)
                .OnDelete(DeleteBehavior.NoAction);
        }
    }
}




