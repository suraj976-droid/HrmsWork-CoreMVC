﻿using System.ComponentModel.DataAnnotations;

namespace CodeFirstApproach.Models
{
    public class Event
    {
        public int EventID { get; set; }

        [Required(ErrorMessage = "Event Type is required")]
        [Display(Name = "Event Type")]
        public int EventTypeID { get; set; }

        [Required(ErrorMessage = "Event Name is required")]
        [Display(Name = "Event Name")]
        [StringLength(200)]
        public string EventName { get; set; }

        [Required(ErrorMessage = "Event Date is required")]
        [Display(Name = "Event Date")]
        [DataType(DataType.Date)]
        public DateTime EventDate { get; set; }

        // Navigation property for EventType
        public EventType EventType { get; set; }

    }
}
