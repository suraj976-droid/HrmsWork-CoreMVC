﻿using System.ComponentModel.DataAnnotations;

namespace CodeFirstApproach.Models
{
    public class User
    {
        [Key]
        public int id { get; set; }

        [Required(ErrorMessage = "Cannot be Empty")]
        public string email { get; set; }

        [Required(ErrorMessage = "Cannot be Empty")]
        public string app_pass { get; set; }

        [Required(ErrorMessage = "Cannot be Empty")]
        public string role { get; set; }

        [Required(ErrorMessage = "Cannot be Empty")]
        public bool status { get; set; }


        [Required(ErrorMessage = "Cannot be Empty")]
        public string username { get; set; }
    }
}
