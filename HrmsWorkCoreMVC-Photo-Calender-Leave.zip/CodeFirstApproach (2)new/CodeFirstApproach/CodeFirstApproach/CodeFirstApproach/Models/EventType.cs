﻿using System.ComponentModel.DataAnnotations;

namespace CodeFirstApproach.Models
{
    public class EventType
    {
        public int EventTypeID { get; set; }

        [Required(ErrorMessage = "Event Type Name is required")]
        [Display(Name = "Event Type")]
        [StringLength(100)]
        public string EventTypeName { get; set; }

        [Required(ErrorMessage = "Color Code is required")]
        [Display(Name = "Color Code")]
        [StringLength(10)]
        public string ColorCode { get; set; }

        [Display(Name = "Status")]
        public bool Status { get; set; }
    }
}
