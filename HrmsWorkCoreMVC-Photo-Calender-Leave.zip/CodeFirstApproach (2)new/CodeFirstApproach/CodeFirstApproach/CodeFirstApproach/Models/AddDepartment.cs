﻿using System.ComponentModel.DataAnnotations;

namespace CodeFirstApproach.Models
{
    public class AddDepartment
    {
        [Key]
        public int DeptID { get; set; }

        [Required(ErrorMessage = "Department Name is required")]
        public string DeptName { get; set; }

        public bool? Status { get; set; } // Nullable boolean for Active/Inactive
    }
}
