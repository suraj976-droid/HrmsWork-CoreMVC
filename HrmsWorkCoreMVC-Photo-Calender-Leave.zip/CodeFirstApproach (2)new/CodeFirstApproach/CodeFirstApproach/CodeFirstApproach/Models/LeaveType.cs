﻿namespace CodeFirstApproach.Models
{
    public class LeaveType
    {
        public int LeaveTypeID { get; set; }
        public string LeaveTypeName { get; set; }
        public int MaxDays { get; set; }
        public string Status { get; set; }
    }
}
