﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CodeFirstApproach.Models
{
    public class AddEmployee
    {
        [Key]
        public int EmpID { get; set; }

        [Required(ErrorMessage = "Employee Name is required")]
        public string EmpName { get; set; }

        [Required(ErrorMessage = "Employee Email is required")]
        [EmailAddress(ErrorMessage = "Invalid Email Address")]
        public string EmpEmail { get; set; }

        [Required(ErrorMessage = "Employee Contact is required")]
        [Phone(ErrorMessage = "Invalid Phone Number")]
        public string EmpContact { get; set; }

        [Required(ErrorMessage = "Employee Role is required")]
        public int EmpRole { get; set; } // Foreign key for Role

        [Required(ErrorMessage = "Employee Department is required")]
        public int EmpDepartment { get; set; } // Foreign key for AddDepartment

        [Required(ErrorMessage = "Employee Designation is required")]
        public int EmpDesignation { get; set; } // Foreign key for AddDesignation

        [Required(ErrorMessage = "Employee Reporting Manager is required")]
        public int EmpReportingManager { get; set; } // Foreign key for RManager

        [Required(ErrorMessage = "Employee Status is required")]
        public bool EmpStatus { get; set; } // Active or Inactive

        public string Password { get; set; }

        // Navigation properties
        [ForeignKey("EmpRole")]
        public Role Role { get; set; }

        [ForeignKey("EmpDepartment")]
        public AddDepartment Department { get; set; }

        [ForeignKey("EmpDesignation")]
        public AddDesignation Designation { get; set; }

        [ForeignKey("EmpReportingManager")]
        public RManager ReportingManager { get; set; }

    }
}
