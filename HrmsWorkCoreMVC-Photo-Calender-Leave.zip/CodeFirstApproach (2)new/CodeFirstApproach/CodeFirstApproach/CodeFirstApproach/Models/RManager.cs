﻿using System.ComponentModel.DataAnnotations;

namespace CodeFirstApproach.Models
{
    public class RManager
    {
        [Key]
        public int RmID { get; set; }

        [Required(ErrorMessage = "Reporting Manager Name is required")]
        public string ReportingManagerName { get; set; }
    }
}
