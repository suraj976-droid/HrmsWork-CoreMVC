﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace CodeFirstApproach.Migrations
{
    /// <inheritdoc />
    public partial class AddEmployeeTable : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "AddEmployee",
                columns: table => new
                {
                    EmpID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    EmpName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    EmpEmail = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    EmpContact = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    EmpRole = table.Column<int>(type: "int", nullable: false),
                    EmpDepartment = table.Column<int>(type: "int", nullable: false),
                    EmpDesignation = table.Column<int>(type: "int", nullable: false),
                    EmpReportingManager = table.Column<int>(type: "int", nullable: false),
                    EmpStatus = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AddEmployee", x => x.EmpID);
                    table.ForeignKey(
                        name: "FK_AddEmployee_AddDepartment_EmpDepartment",
                        column: x => x.EmpDepartment,
                        principalTable: "AddDepartment",
                        principalColumn: "DeptID");
                    table.ForeignKey(
                        name: "FK_AddEmployee_AddDesignation_EmpDesignation",
                        column: x => x.EmpDesignation,
                        principalTable: "AddDesignation",
                        principalColumn: "DesigID");
                    table.ForeignKey(
                        name: "FK_AddEmployee_RManager_EmpReportingManager",
                        column: x => x.EmpReportingManager,
                        principalTable: "RManager",
                        principalColumn: "RmID");
                    table.ForeignKey(
                        name: "FK_AddEmployee_Role_EmpRole",
                        column: x => x.EmpRole,
                        principalTable: "Role",
                        principalColumn: "RoleID");
                });

            migrationBuilder.CreateIndex(
                name: "IX_AddEmployee_EmpDepartment",
                table: "AddEmployee",
                column: "EmpDepartment");

            migrationBuilder.CreateIndex(
                name: "IX_AddEmployee_EmpDesignation",
                table: "AddEmployee",
                column: "EmpDesignation");

            migrationBuilder.CreateIndex(
                name: "IX_AddEmployee_EmpReportingManager",
                table: "AddEmployee",
                column: "EmpReportingManager");

            migrationBuilder.CreateIndex(
                name: "IX_AddEmployee_EmpRole",
                table: "AddEmployee",
                column: "EmpRole");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "AddEmployee");
        }
    }
}
