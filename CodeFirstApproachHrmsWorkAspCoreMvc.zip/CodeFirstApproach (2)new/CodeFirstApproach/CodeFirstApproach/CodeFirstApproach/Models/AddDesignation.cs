﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CodeFirstApproach.Models
{
    public class AddDesignation
    {
        [Key]
        public int DesigID { get; set; }

        [Required(ErrorMessage = "Designation Name is required")]
        public string DesigName { get; set; }

        [Required(ErrorMessage = "Department is required")]
        public int DeptID { get; set; } // Foreign key for Department

        [ForeignKey("DeptID")] // Define foreign key relationship
        public AddDepartment Department { get; set; } // Navigation property

        public bool? Status { get; set; } // Nullable boolean for Active/Inactive
    }
}