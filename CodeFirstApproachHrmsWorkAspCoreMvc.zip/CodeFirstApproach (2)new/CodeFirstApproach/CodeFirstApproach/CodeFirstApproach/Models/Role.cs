﻿using System.ComponentModel.DataAnnotations;

namespace CodeFirstApproach.Models
{
    public class Role
    {
        [Key]
        public int RoleID { get; set; }

        [Required(ErrorMessage = "Role Name is required")]
        public string RoleName { get; set; }

        [Required(ErrorMessage = "Role Status is required")]
        public string RoleStatus { get; set; } // Active or Inactive
    }
}
