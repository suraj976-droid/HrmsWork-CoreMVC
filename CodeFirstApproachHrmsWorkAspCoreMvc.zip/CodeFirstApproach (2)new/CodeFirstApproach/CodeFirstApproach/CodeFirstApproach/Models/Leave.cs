﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace CodeFirstApproach.Models
{
    public class Leave
    {
        [Key]
        public int LeaveID { get; set; }

        [Required]
        public int UserID { get; set; }

        [Required]
        public int LeaveTypeID { get; set; }

        [Required]
        [DataType(DataType.Date)]
        public DateTime FromDate { get; set; }

        [Required]
        [DataType(DataType.Date)]
        public DateTime ToDate { get; set; }

        public string? Message { get; set; }

        [Required]
        [StringLength(20)]
        public string Status { get; set; } = "Pending"; // Default status

        // Navigation Properties
        [ForeignKey("UserID")]
        public virtual User? User { get; set; }

        [ForeignKey("LeaveTypeID")]
        public virtual LeaveType? LeaveType { get; set; }
    }
}
