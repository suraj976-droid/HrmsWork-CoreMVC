﻿namespace CodeFirstApproach.Models
{
    public class RemainingLeaveViewModel
    {
        public string LeaveTypeName { get; set; }
        public int MaxDays { get; set; }
        public int UsedDays { get; set; }
        public int RemainingDays => MaxDays - UsedDays;
    }
}
