﻿using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using CodeFirstApproach.Data;
using CodeFirstApproach.Models;

namespace CodeFirstApproach.Controllers
{
    public class LeaveController : Controller
    {
        private readonly ApplicationDbContext _context;

        public LeaveController(ApplicationDbContext context)
        {
            _context = context;
        }

        public IActionResult RemainingLeave()
        {
            // Get the logged-in user's ID from the session
            var userId = HttpContext.Session.GetInt32("userId");
            if (userId == null)
            {
                return RedirectToAction("SignIn", "Auth");
            }

            // Fetch all leave types from the database
            var leaveTypes = _context.LeaveTypes.ToList();

            // Fetch all leaves taken by the user
            var userLeaves = _context.leaves // Use 'leaves' instead of 'Leaves'
                .Where(l => l.UserID == userId)
                .ToList();

            // Calculate remaining leave for each leave type
            var remainingLeaves = new List<RemainingLeaveViewModel>();

            foreach (var leaveType in leaveTypes)
            {
                // Calculate the total used days for this leave type
                var usedDays = userLeaves
                    .Where(l => l.LeaveTypeID == leaveType.LeaveTypeID)
                    .Sum(l => (l.ToDate - l.FromDate).Days);

                // Add the remaining leave data to the view model
                remainingLeaves.Add(new RemainingLeaveViewModel
                {
                    LeaveTypeName = leaveType.LeaveTypeName,
                    MaxDays = leaveType.MaxDays,
                    UsedDays = usedDays
                });
            }

            // Pass the view model to the view
            return View(remainingLeaves);
        }
    }
}