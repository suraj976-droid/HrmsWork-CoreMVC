﻿using CodeFirstApproach.Data;
using CodeFirstApproach.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CodeFirstApproach.Controllers
{
    public class RoleController : Controller
    {
        private readonly ApplicationDbContext db;

        public RoleController(ApplicationDbContext db)
        {
            this.db = db;
        }

        // Index: Display all roles
        public IActionResult Index()
        {
            var data = db.Role.ToList(); // Use Role table
            return View(data);
        }

        // AddRole: Display the form to add a new role
        public IActionResult AddRole()
        {
            return View();
        }

        // AddRole: Handle form submission
        [HttpPost]
        public IActionResult AddRole(Role role)
        {
            if (ModelState.IsValid)
            {
                db.Role.Add(role); // Use Role table
                db.SaveChanges();
                TempData["success"] = "Role Added Successfully!!";
                return RedirectToAction("Index");
            }
            return View(role);
        }

        // DeleteRole: Delete a role by ID
        public IActionResult DeleteRole(int id)
        {
            var data = db.Role.Find(id); // Use Role table
            if (data != null)
            {
                db.Role.Remove(data); // Use Role table
                db.SaveChanges();
                TempData["error"] = "Role Deleted Successfully!!";
                return RedirectToAction("Index");
            }
            return NotFound();
        }

        // EditRole: Display the form to edit a role
        public IActionResult EditRole(int id)
        {
            var data = db.Role.Find(id); // Use Role table
            if (data == null)
            {
                return NotFound();
            }
            return View(data);
        }

        // EditRole: Handle form submission for editing
        [HttpPost]
        public IActionResult EditRole(Role role)
        {
            if (ModelState.IsValid)
            {
                db.Role.Update(role); // Use Role table
                db.SaveChanges();
                TempData["upd"] = "Role Updated Successfully!!";
                return RedirectToAction("Index");
            }
            return View(role);
        }
    }
}
