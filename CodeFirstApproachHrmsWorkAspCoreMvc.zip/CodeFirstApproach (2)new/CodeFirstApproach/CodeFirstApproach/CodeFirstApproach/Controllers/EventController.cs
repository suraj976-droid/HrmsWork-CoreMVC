﻿using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using CodeFirstApproach.Data; // Replace with your namespace
using CodeFirstApproach.Models;

namespace CodeFirstApproach.Controllers
{
    public class EventController : Controller
    {
        private readonly ApplicationDbContext _context;

        public EventController(ApplicationDbContext context)
        {
            _context = context;
        }

        public IActionResult Calendar()
        {
            // Fetch events from the database
            var events = _context.Events
                .Include(e => e.EventType) // Join with EventTypes table
                .Select(e => new EventViewModel
                {
                    EventID = e.EventID,
                    EventName = e.EventName,
                    EventDate = e.EventDate,
                    EventTypeName = e.EventType.EventTypeName,
                    ColorCode = e.EventType.ColorCode
                })
                .ToList();

            return View(events);
        }

        // API endpoint for FullCalendar to fetch events
        public IActionResult GetEvents()
        {
            var events = _context.Events
                .Include(e => e.EventType)
                .Select(e => new
                {
                    id = e.EventID,
                    title = e.EventName,
                    start = e.EventDate.ToString("yyyy-MM-dd"),
                    color = e.EventType.ColorCode
                })
                .ToList();

            return Json(events);
        }

    }
}
