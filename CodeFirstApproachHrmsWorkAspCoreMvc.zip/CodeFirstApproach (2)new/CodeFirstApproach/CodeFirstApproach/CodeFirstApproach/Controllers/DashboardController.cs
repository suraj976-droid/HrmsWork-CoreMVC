﻿using Microsoft.AspNetCore.Mvc;

namespace CodeFirstApproach.Controllers
{
    public class DashboardController : Controller
    {
        public IActionResult AdminDashboard()
        {
            if(HttpContext.Session.GetString("MyUser") != null)
            {
                ViewBag.uname = HttpContext.Session.GetString("MyUser").ToString();
                return View();

            }
            else
            {
                return RedirectToAction("SignIn", "Auth");
            }
        }

        public IActionResult EmployeeDashboard()
        {
            if (HttpContext.Session.GetString("MyUser") != null)
            {
                ViewBag.uname = HttpContext.Session.GetString("MyUser").ToString();
                return View();

            }
            else
            {
                return RedirectToAction("SignIn", "Auth");
            }
        }
        public IActionResult ManagerDashboard()
        {
            if (HttpContext.Session.GetString("MyUser") != null)
            {
                ViewBag.uname = HttpContext.Session.GetString("MyUser").ToString();
                return View();

            }
            else
            {
                return RedirectToAction("SignIn", "Auth");
            }
        }
    }
}
