﻿using CodeFirstApproach.Data;
using CodeFirstApproach.Models;
using Microsoft.AspNetCore.Mvc;

namespace CodeFirstApproach.Controllers
{
    public class AuthController : Controller
    {
        private readonly ApplicationDbContext db;

        public AuthController(ApplicationDbContext db)
        {
            this.db = db;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult SignUp()
        {
            return View();
        }

        [HttpPost]
        public IActionResult SignUp(User u)
        {
            if (!ModelState.IsValid)
            {
                // Log or inspect ModelState errors
                var errors = ModelState.Values.SelectMany(v => v.Errors);
                foreach (var error in errors)
                {
                    Console.WriteLine(error.ErrorMessage);
                }
                return View(u); // Return the model back to the view to display validation errors
            }

            try
            {
                db.users.Add(u);
                db.SaveChanges();
                TempData["success"] = "User Registered Successfully!";
                return RedirectToAction("SignIn");
            }
            catch (Exception ex)
            {
                // Handle unexpected errors
                TempData["error"] = "An error occurred while registering. Please try again.";
                Console.WriteLine(ex.Message);  // Log the error for debugging purposes
                return View(u);
            }
        }


        public IActionResult SignIn()
        {
            return View();
        }

        [HttpPost]
        public IActionResult SignIn(string Email, string Password)
        {
            if (!ModelState.IsValid)
            {
                return View();
            }

            var user = db.users.SingleOrDefault(x => x.email.Equals(Email) && x.app_pass.Equals(Password));

            if (user != null)
            {
                bool admin = user.role.Equals("admin");
                bool emp = user.role.Equals("Employee");
                bool manager = user.role.Equals("Manager");

                string username = user.username;

                if (admin)
                {
                    TempData["success"] = $"Logged with {user.email}";
                    HttpContext.Session.SetInt32("userId", user.id);
                    HttpContext.Session.SetString("MyUser", username);
                    HttpContext.Session.SetString("MyRole", "admin");
                    return RedirectToAction("AdminDashboard", "Dashboard");
                }
                if (emp)
                {
                    TempData["success"] = $"Logged with {user.email}";
                    HttpContext.Session.SetInt32("userId", user.id);
                    HttpContext.Session.SetString("MyUser", username);
                    HttpContext.Session.SetString("MyRole", "Employee");
                    return RedirectToAction("EmployeeDashboard", "Dashboard");
                }
                if (manager)
                {
                    TempData["success"] = $"Logged with {user.email}";
                    HttpContext.Session.SetInt32("userId", user.id);
                    HttpContext.Session.SetString("MyUser", username);
                    HttpContext.Session.SetString("MyRole", "Manager");
                    return RedirectToAction("ManagerDashboard", "Dashboard");
                }
            }
            else
            {
                TempData["error"] = "Invalid Email or Password";
            }

            return View();
        }

        public IActionResult SignOut()
        {
            HttpContext.Session.Remove("MyUser");
            HttpContext.Session.Clear();
            return RedirectToAction("SignIn");
        }

    }
}