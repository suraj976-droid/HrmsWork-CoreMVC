﻿using CodeFirstApproach.Data;
using CodeFirstApproach.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CodeFirstApproach.Controllers
{
    public class EmployeeController : Controller
    {
        private readonly ApplicationDbContext db;

        public EmployeeController(ApplicationDbContext db)
        {
            this.db = db;
        }

        // Index: Display all employees
        public IActionResult Index()
        {
            var data = db.AddEmployee
                         .Include(e => e.Role)
                         .Include(e => e.Department)
                         .Include(e => e.Designation)
                         .Include(e => e.ReportingManager)
                         .ToList();
            return View(data);
        }

        // AddEmployee: Display the form to add a new employee
        public IActionResult AddEmployee()
        {
            ViewBag.Roles = db.Role.ToList(); // Populate Role dropdown
            ViewBag.Departments = db.AddDepartment.ToList(); // Populate Department dropdown
            ViewBag.Designations = db.AddDesignation.ToList(); // Populate Designation dropdown
            ViewBag.ReportingManagers = db.RManager.ToList(); // Populate Reporting Manager dropdown
            return View();
        }

        // AddEmployee: Handle form submission
        [HttpPost]
        public IActionResult AddEmployee(AddEmployee employee)
        {
         
                db.AddEmployee.Add(employee);
                db.SaveChanges();
                TempData["success"] = "Employee Added Successfully!!";
                return RedirectToAction("Index");
            

          
        }

        // EditEmployee: Display the form to edit an employee
        public IActionResult EditEmployee(int id)
        {
            var data = db.AddEmployee.Find(id);
            if (data == null)
            {
                return NotFound();
            }

            ViewBag.Roles = db.Role.ToList();
            ViewBag.Departments = db.AddDepartment.ToList();
            ViewBag.Designations = db.AddDesignation.ToList();
            ViewBag.ReportingManagers = db.RManager.ToList();
            return View(data);
        }

        // EditEmployee: Handle form submission for editing
        [HttpPost]
        public IActionResult EditEmployee(AddEmployee employee)
        {
            
                db.AddEmployee.Update(employee);
                db.SaveChanges();
                TempData["upd"] = "Employee Updated Successfully!!";
                return RedirectToAction("Index");
            

        
        }

        // DeleteEmployee: Delete an employee by ID
        public IActionResult DeleteEmployee(int id)
        {
            var data = db.AddEmployee.Find(id);
            if (data != null)
            {
                db.AddEmployee.Remove(data);
                db.SaveChanges();
                TempData["error"] = "Employee Deleted Successfully!!";
                return RedirectToAction("Index");
            }
            return NotFound();
        }
    }
}