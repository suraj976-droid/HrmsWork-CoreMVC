﻿using CodeFirstApproach.Data;
using CodeFirstApproach.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;


namespace CodeFirstApproach.Controllers
{
    public class DepartmentController : Controller
    {
        private readonly ApplicationDbContext db;

        public DepartmentController(ApplicationDbContext db)
        {
            this.db = db;
        }

        // Index: Display all AddDepartment
        public IActionResult Index()
        {
            var data = db.AddDepartment.ToList();
            return View(data);
        }

        // AddDepartment: Display the form to add a new department
        public IActionResult AddDepartment()
        {
            return View();
        }

        // AddDepartment: Handle form submission
        [HttpPost]
        public IActionResult AddDepartment(AddDepartment dept)
        {
            if (ModelState.IsValid)
            {
                db.AddDepartment.Add(dept);
                db.SaveChanges();
                TempData["success"] = "Department Added Successfully!!";
                return RedirectToAction("Index");
            }
            return View(dept);
        }

        // DeleteDepartment: Delete a department by ID
        public IActionResult DeleteDepartment(int id)
        {
            var data = db.AddDepartment.Find(id);
            if (data != null)
            {
                db.AddDepartment.Remove(data);
                db.SaveChanges();
                TempData["error"] = "Department Deleted Successfully!!";
                return RedirectToAction("Index");
            }
            return NotFound();
        }

        // EditDepartment: Display the form to edit a department
        public IActionResult EditDepartment(int id)
        {
            var data = db.AddDepartment.Find(id);
            if (data == null)
            {
                return NotFound();
            }
            return View(data);
        }

        // EditDepartment: Handle form submission for editing
        [HttpPost]
        public IActionResult EditDepartment(AddDepartment dept)
        {
            if (ModelState.IsValid)
            {
                db.AddDepartment.Update(dept);
                db.SaveChanges();
                TempData["upd"] = "Department Updated Successfully!!";
                return RedirectToAction("Index");
            }
            return View(dept);
        }
    }
}
