﻿using CodeFirstApproach.Data;
using CodeFirstApproach.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Linq;


namespace CodeFirstApproach.Controllers
{
    public class EventsController : Controller
    {
        private readonly ApplicationDbContext db;

        public EventsController(ApplicationDbContext db)
        {
            this.db = db;
        }

        // GET: Events
        public IActionResult Index()
        {
            var data = db.Events.Include(e => e.EventType).ToList(); // Include EventType for display
            return View(data);
        }

        // GET: Events/AddEvent
        public IActionResult AddEvent()
        {
            ViewBag.EventTypes = db.EventTypes.ToList(); // Populate dropdown for EventTypes
            return View();
        }

        // POST: Events/AddEvent
        [HttpPost]
        [HttpPost]
        public IActionResult AddEvent(Event e)
        {
            db.Events.Add(e);
            db.SaveChanges();
            TempData["success"] = "Event Added Successfully!!";
            return RedirectToAction("Index");
        }

        // GET: Events/DeleteEvent
        public IActionResult DeleteEvent(int id)
        {
            var data = db.Events.Find(id);
            if (data != null)
            {
                db.Events.Remove(data);
                db.SaveChanges();
                TempData["error"] = "Event Deleted Successfully!!";
                return RedirectToAction("Index");
            }
            else
            {
                return NotFound();
            }
        }

        // GET: Events/EditEvent
        public IActionResult EditEvent(int id)
          {
            var data = db.Events.Find(id);
            ViewBag.EventTypes = db.EventTypes.ToList(); // Populate dropdown for EventTypes
            return View(data);
        }

        // POST: Events/EditEvent
        [HttpPost]
        public IActionResult EditEvent(Event e)
        {
            db.Events.Update(e);
            db.SaveChanges();
            TempData["upd"] = "Event Updated Successfully!!";
            return RedirectToAction("Index");
        }
    }
}
