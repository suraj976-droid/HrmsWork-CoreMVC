﻿using CodeFirstApproach.Data;
using CodeFirstApproach.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CodeFirstApproach.Controllers
{
    public class AdminLeaveController : Controller
    {
        private readonly ApplicationDbContext db;

        public AdminLeaveController(ApplicationDbContext db)
        {
            this.db = db;
        }
        public IActionResult Index()
        {
            var data = db.LeaveTypes.ToList();
            return View(data);
        }

        public IActionResult AddLeaveType()
        {
            return View();
        }

        [HttpPost]
        public IActionResult AddLeaveType(LeaveType leaveType)
        {
            if (ModelState.IsValid)
            {
                db.LeaveTypes.Add(leaveType);
                db.SaveChanges();
                TempData["success"] = "Leave Type Added Successfully!";
                return RedirectToAction("AdminDashboard", "Dashboard");
            }
            else
            {
                return View();
            }
        }

        public IActionResult DeleteLeaveType(int id)
        {
            var data = db.LeaveTypes.Find(id);
            if (data != null)
            {
                db.LeaveTypes.Remove(data);
                db.SaveChanges();
                TempData["error"] = "Leave Type Deleted Successfully!";
                return RedirectToAction("AdminDashboard");
            }
            else
            {
                return NotFound();
            }
        }
    }
}