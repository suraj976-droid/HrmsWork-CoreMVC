﻿using CodeFirstApproach.Data;
using CodeFirstApproach.Models;
using Microsoft.AspNetCore.Mvc;

namespace CodeFirstApproach.Controllers
{
    public class EmpController : Controller
    {

        private readonly ApplicationDbContext db;

        public EmpController(ApplicationDbContext db)
        {
            this.db = db;
        }
        public IActionResult Index()
        {
            var data = db.emps.ToList();
            return View(data);
        }

        public IActionResult AddEmp()
        {
            return View();
        }

        [HttpPost]
        public IActionResult AddEmp(Emp e)
        {
            if(ModelState.IsValid)
            {
                db.emps.Add(e);
                db.SaveChanges();
                TempData["success"] = "Emp Added Successfully!!"; 
                return RedirectToAction("Index");
            }
            else
            {
                return View();
            }
        }

        public IActionResult DeleteEmp(int id)
        {
            //var data = db.emps.Where(x => x.empId.Equals(id)).SingleOrDefault();
            var data = db.emps.Find(id);
            if(data != null)
            {
                db.emps.Remove(data);
                db.SaveChanges();
                TempData["error"] = "Emp Deleted Successfully!!";
                return RedirectToAction("Index");
            }
            else
            {
                return NotFound();
            }
        }

        public IActionResult EditEmp(int id)
        {
            var data = db.emps.Find(id);
            return View(data);
        }

        [HttpPost]
        public IActionResult EditEmp(Emp e)
        {
            if (ModelState.IsValid)
            {
                db.emps.Update(e);
                db.SaveChanges();
                TempData["upd"] = "Emp Updated Successfully!!";
                return RedirectToAction("Index");
            }
            else
            {
                return View();
            }
        }
    }
}
